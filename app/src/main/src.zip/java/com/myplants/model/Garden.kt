package com.myplants.model

data class Garden(
    val userId: String,
    val ownerName: String,
    val ownerImageUrl: String
)
